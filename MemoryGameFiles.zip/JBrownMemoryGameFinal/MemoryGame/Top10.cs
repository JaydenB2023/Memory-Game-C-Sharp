﻿using System;
using System.Data.OleDb;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace MemoryGame
{
    public partial class Top10 : Form
    {

        public Top10()
        {
            InitializeComponent();
        }

        

        private void Top10_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader streamIn = File.OpenText(@"gameData.txt");
                string inRec = streamIn.ReadLine();//stores each line read from file - returns "null at end of file

                while (inRec != null)
                {
                    this.Text += "*";
                    listBox1.Items.Add(inRec);
                    inRec = streamIn.ReadLine();
                }

                streamIn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error Trap: " + ex.ToString());
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }
    }
}
